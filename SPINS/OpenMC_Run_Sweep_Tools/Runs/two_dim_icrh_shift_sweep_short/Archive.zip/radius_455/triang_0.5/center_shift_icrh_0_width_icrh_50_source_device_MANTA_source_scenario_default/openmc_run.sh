#!/bin/bash
#PBS -V
#PBS -q fill
#PBS -l nodes=1:ppn=8
#PBS -N MANTA_R455_T0.5

### Store starting dir
START_DIR=$(pwd)

### cd working directory
cd /home/btaczak/OpenMC_Run_Sweep_Tools/Runs/two_dim_icrh_shift_sweep_short/radius_455/triang_0.5/center_shift_icrh_0_width_icrh_50_source_device_MANTA_source_scenario_default

### Executable Line

source /home/btaczak/.bashrc

conda activate openmc-env

export OPENMC_CROSS_SECTIONS=/opt/DagMC/git/nuclear_data/hdf5_version3/tend_2017_hdf5/cross_sections.xml
export HDF5_USE_FILE_LOCKING='FALSE'

python geometry_builder.py > geometry_build.log 2>&1
echo "GEOMETRY BUILD COMPLETE FOR MANTA_R455_T0.5"

python openmc_runner.py > output.log 2>&1
echo "STARTED RUN MANTA_R455_T0.5"

cd "$START_DIR"